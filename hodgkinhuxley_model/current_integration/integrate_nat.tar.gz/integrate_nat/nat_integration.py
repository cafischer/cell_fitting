from __future__ import division
import numpy as np
import pylab as pl
import pandas as pd
import scipy.optimize
from scipy.integrate import ode


# functions
def rates(vm, Ra, Rb, qa, tha, Rd, Rg, qi, thi1, thi2, thinf, qinf, q10, celsius, temp):
    a = Ra * qa * efun((tha - vm)/qa)
    b = Rb * qa * efun((vm - tha)/qa)

    tadj = q10**((celsius - temp)/10)

    mtau = 1/tadj/(a+b)
    minf = a/(a+b)

    a = Rd * qi * efun((thi1 - vm)/qi)
    b = Rg * qi * efun((vm - thi2)/qi)

    htau = 1/tadj/(a+b)
    hinf = 1/(1+np.exp((vm-thinf)/qinf))

    return mtau, minf, htau, hinf


def efun(x):
    if np.abs(x) < 1e-6:
        y = 1 - x/2
    else:
        y = x/(np.exp(x) - 1)
    return y


def slope_intercept_mh(vm):
    mtau, minf, htau, hinf = rates(vm+vshift, Ra, Rb, qa, tha, Rd, Rg, qi, thi1, thi2, thinf, qinf, q10, celsius, temp)
    return -1/mtau, -1/htau, minf/mtau, hinf/htau


# parameters from simulation
celsius = 36
ena = 83

# load data
data = pd.read_csv('./nat_neuronsim.csv').convert_objects(convert_numeric=True)
v = np.array(data.v)
t = np.array(data.t)
dt = t[1] - t[0]

# channel parameter
vshift = 0  # (mV)
gbar = 10  # (pS/um2)
tha = -35  # (mV)
qa = 9  # (mV)
Ra = 0.182  # (/ms)
Rb = 0.124  # (/ms)
thi1 = -50  # (mV)
thi2 = -75  # (mV)
qi = 5  # (mV)
thinf = -65  # (mV)
qinf = 6.2  # (mV)
Rg = 0.0091  # (/ms)
Rd = 0.024  # (/ms)
temp = 23  # (degC)
q10 = 3
vin = -120  # (mV)
vax = 100  # (mV)
tadj = q10**((celsius - temp)/10)

# initialization
mtau, minf, htau, hinf = rates(v[0], Ra, Rb, qa, tha, Rd, Rg, qi, thi1, thi2, thinf, qinf, q10, celsius, temp)
m0 = minf
h0 = hinf
ina0 = 1e-4 * gbar*m0**3*h0 * (v[0] - ena)

# compute slope and intercept of m, h
m_slope = np.zeros(len(t))
h_slope = np.zeros(len(t))
m_intercept = np.zeros(len(t))
h_intercept = np.zeros(len(t))
m_slope[0], h_slope[0], m_intercept[0], h_intercept[0] = slope_intercept_mh(v[0])
for i in range(1, len(t)):
    m_slope[i], h_slope[i], m_intercept[i], h_intercept[i] = slope_intercept_mh(v[i-1])  # v from the previous time step


# integration: Exponential Euler

def phi(z):
    return (np.exp(z) - 1) / z

m_expeuler = np.zeros(len(t))
m_expeuler[0] = m0
h_expeuler = np.zeros(len(t))
h_expeuler[0] = h0
ina_expeuler = np.zeros(len(t))
ina_expeuler[0] = ina0

for i in range(1, len(t)):
    m_expeuler[i] = dt * phi(m_slope[i]*dt) * m_intercept[i-1] + m_expeuler[i-1] * np.exp(m_slope[i]*dt)
    h_expeuler[i] = dt * phi(h_slope[i]*dt) * h_intercept[i-1] + h_expeuler[i-1] * np.exp(h_slope[i]*dt)

    # compute current
    ina_expeuler[i] = 1e-4 * gbar*m_expeuler[i]**3*h_expeuler[i] * (v[i-1] - ena)  # v from the previous time step


# integration: Implicit (backward) Euler

def fun_m(m, m_old, dt, m_slope, m_intercept):
    return m - m_old - dt * (m_slope*m+m_intercept)

def fun_h(h, h_old, dt, h_slope, h_intercept):
    return h - h_old - dt * (h_slope*h+h_intercept)

def funprime_m(m, m_old, dt, m_slope, m_intercept):
    return 1 - dt * m_slope

def funprime_h(h, h_old, dt, h_slope, h_intercept):
    return 1 - dt * h_slope


m_impeuler = np.zeros(len(t))
m_impeuler[0] = m0
h_impeuler = np.zeros(len(t))
h_impeuler[0] = h0
ina_impeuler = np.zeros(len(t))
ina_impeuler[0] = ina0

for i in range(1, len(t)):
    m_impeuler[i] = scipy.optimize.newton(fun_m, 0, funprime_m, args=(m_impeuler[i-1], dt, m_slope[i], m_intercept[i]))
    h_impeuler[i] = scipy.optimize.newton(fun_h, 0, funprime_h, args=(h_impeuler[i-1], dt, h_slope[i], h_intercept[i]))

    # compute current
    ina_impeuler[i] = 1e-4 * gbar*m_impeuler[i]**3*h_impeuler[i] * (v[i-1] - ena)


# integration: vode

def dmhdt(t, y):
    [m, h] = y

    mtau, minf, htau, hinf = rates(v[t]+vshift, Ra, Rb, qa, tha, Rd, Rg, qi, thi1, thi2, thinf, qinf,
                                   q10, celsius, temp)

    return [(-1*m+minf)/mtau, (-1*h+hinf)/htau]

solve_mh = ode(dmhdt).set_integrator('vode', method='bdf')
solve_mh.set_initial_value([m0, h0], 0)

ina_vode = np.zeros(len(t))
ina_vode[0] = ina0

while solve_mh.successful() and solve_mh.t < (len(t)-1):
    solve_mh.integrate(solve_mh.t+1)
    [m3, h3] = solve_mh.y

    ina_vode[solve_mh.t] = 1e-4 * gbar*m3**3*h3 * (v[solve_mh.t] - ena)


with open('nat_neuronsim.npy', 'r') as f:
    ina_neuron = np.load(f)

pl.figure()
pl.plot(t, ina_neuron, 'r', linewidth=1.5, label='NEURON \nsimulation')
pl.plot(t, ina_expeuler, 'k', linewidth=1.5, label='Exponential Euler')
pl.plot(t, ina_impeuler, 'y', linewidth=1.5, label='Implicit Euler')
pl.plot(t, ina_vode, 'g', linewidth=1.5, label='Vode (bdf)')
pl.xlabel('$Time (ms)$', fontsize=18)
pl.ylabel('$Current (pS/\mu m^2)$', fontsize=18)
pl.legend(loc='lower right', fontsize=18)
pl.show()